import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  User, 
  LogOut, 
  BookmarkCheck, 
  CalendarRange, 
  Lock, 
  FileText, 
  Smartphone, 
  Check, 
  Loader2,
  CalendarDays,
  UserCheck,
  AlertCircle
} from 'lucide-react';
import { 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  writeBatch, 
  doc, 
  serverTimestamp,
  getDocFromServer
} from 'firebase/firestore';

import { auth, db, isFirebaseConfigured, handleFirestoreError, OperationType } from './firebase';
import { getUpcomingDays, formatBilingualDate, DayItem } from './utils';
import { Booking, BookedSlot, TimeSlotConfig, CalendarSettingsType } from './types';
import { translations } from './translations';

// Standard working hour slots
const TIME_SLOTS: TimeSlotConfig[] = [
  { time: "09:00", label: "09:00 AM" },
  { time: "10:00", label: "10:00 AM" },
  { time: "11:00", label: "11:00 AM" },
  { time: "12:00", label: "12:00 PM" },
  { time: "13:00", label: "01:00 PM" },
  { time: "14:00", label: "02:00 PM" },
  { time: "15:00", label: "03:00 PM" },
  { time: "16:00", label: "04:00 PM" },
  { time: "17:00", label: "05:00 PM" }
];

const MONTH_NAMES_EN = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const MONTH_NAMES_UR = ["جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"];
const WEEKDAYS_EN = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const WEEKDAYS_UR = ["اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"];

const getDaysInMonthObj = (relativeDate: Date) => {
  const year = relativeDate.getFullYear();
  const month = relativeDate.getMonth(); // 0-11
  
  // First day of Month
  const firstDay = new Date(year, month, 1);
  const startDayOfWeek = firstDay.getDay(); // 0 (Sun) - 6 (Sat)
  
  // Total days in Month
  const totalDays = new Date(year, month + 1, 0).getDate();
  
  const days: { dayNum: number; dateString: string; isPast: boolean }[] = [];
  
  const today = new Date();
  today.setHours(0,0,0,0);
  
  for (let i = 1; i <= totalDays; i++) {
    const dStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
    const thisDate = new Date(year, month, i);
    thisDate.setHours(0,0,0,0);
    days.push({
      dayNum: i,
      dateString: dStr,
      isPast: thisDate.getTime() < today.getTime()
    });
  }
  
  return {
    startDayOfWeek,
    days,
    year,
    month
  };
};

const getSlotTimeOnly = (time: string) => {
  const [hours, minutes] = time.split(':');
  const hNum = parseInt(hours, 10);
  const period = hNum >= 12 ? 'PM' : 'AM';
  const displayHour = hNum > 12 ? hNum - 12 : hNum === 0 ? 12 : hNum;
  const padHour = String(displayHour).padStart(2, '0');
  return `${padHour}:${minutes} ${period}`;
};

const getLocalizedSlotLabel = (time: string, lang: 'ur' | 'en') => {
  const [hours, minutes] = time.split(':');
  const hNum = parseInt(hours, 10);
  const period = hNum >= 12 ? 'PM' : 'AM';
  const displayHour = hNum > 12 ? hNum - 12 : hNum === 0 ? 12 : hNum;
  const padHour = String(displayHour).padStart(2, '0');
  
  const textMorning = lang === 'ur' ? 'صبح' : 'Morning';
  const textAfternoon = lang === 'ur' ? 'دوپہر' : 'Afternoon';
  const textEvening = lang === 'ur' ? 'شام' : 'Evening';
  
  let periodText = '';
  if (hNum < 12) {
    periodText = textMorning;
  } else if (hNum < 16) {
    periodText = textAfternoon;
  } else {
    periodText = textEvening;
  }

  return `${padHour}:${minutes} ${period} (${periodText})`;
};

export default function App() {
  const [lang, setLang] = useState<'ur' | 'en'>('ur');
  const t = translations[lang];
  const isRtl = lang === 'ur';

  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  
  // Date configuration
  const upcomingDays = getUpcomingDays(14);
  const [selectedDate, setSelectedDate] = useState<string>(upcomingDays[0].dateString);
  const [customDateValue, setCustomDateValue] = useState<string>('');
  const [showCustomDatePicker, setShowCustomDatePicker] = useState(false);
  // Booking status collections
  const [globalBookedSlots, setGlobalBookedSlots] = useState<BookedSlot[]>([]);
  const [globalCustomSlots, setGlobalCustomSlots] = useState<{ id: string; date: string; slot: string; createdBy?: string }[]>([]);
  const [calendarSettings, setCalendarSettings] = useState<CalendarSettingsType>({
    openDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    specialOpenDates: [],
    holidayDates: []
  });
  const [isUpdatingSettings, setIsUpdatingSettings] = useState(false);

  // Admin Config specific dates inputs
  const [adminCustomConfigDate, setAdminCustomConfigDate] = useState<string>('');
  const [adminCustomConfigType, setAdminCustomConfigType] = useState<'special' | 'holiday'>('holiday');

  const [myBookings, setMyBookings] = useState<Booking[]>([]);
  const [reschedulingBooking, setReschedulingBooking] = useState<Booking | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // Derived slot/busy indicators dynamically for backward compatibility
  const customSlots = React.useMemo(() => {
    return globalCustomSlots.filter(cs => cs.date === selectedDate);
  }, [globalCustomSlots, selectedDate]);

  const busySlots = React.useMemo(() => {
    const busyMap: Record<string, { isBooked: boolean; userId: string }> = {};
    globalBookedSlots.forEach(bk => {
      if (bk.date === selectedDate) {
        busyMap[bk.slot] = { isBooked: bk.isBooked, userId: bk.userId };
      }
    });
    return busyMap;
  }, [globalBookedSlots, selectedDate]);
  
  // Loading states for dynamic components
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [bookingsLoading, setBookingsLoading] = useState(true);
  const [allBookingsLoading, setAllBookingsLoading] = useState(true);
  
  // Admin only state
  const [allBookings, setAllBookings] = useState<Booking[]>([]);
  const [adminSelectedDate, setAdminSelectedDate] = useState<string>(upcomingDays[0].dateString);
  const [adminSelectedTime, setAdminSelectedTime] = useState<string>('09:00');
  const [isAdminCreatingSlot, setIsAdminCreatingSlot] = useState(false);

  // Derived admin detection based on specified bootstrapped email
  const isAdminUser = !!user && user.email === 'ikram.bhatti93@gmail.com';
  
  const [currentMonthDate, setCurrentMonthDate] = useState(() => new Date());

  // Helper to check if a slot is in the past
  const checkIsPastSlot = (time: string, dateToCheck?: string) => {
    const activeDate = dateToCheck || selectedDate;
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const currentTodayStr = `${year}-${month}-${day}`;
    
    if (activeDate === currentTodayStr) {
      const [slotHour, slotMinute] = time.split(':').map(Number);
      const currentHour = now.getHours();
      const currentMinute = now.getMinutes();
      
      if (slotHour < currentHour || (slotHour === currentHour && slotMinute <= currentMinute)) {
        return true;
      }
    }
    
    // Check if the selected date itself is also in the past
    const [selYear, selMonth, selDay] = activeDate.split('-').map(Number);
    const selDateObj = new Date(selYear, selMonth - 1, selDay);
    selDateObj.setHours(0,0,0,0);
    
    const todayStart = new Date(year, now.getMonth(), now.getDate());
    todayStart.setHours(0,0,0,0);
    
    if (selDateObj.getTime() < todayStart.getTime()) {
      return true;
    }
    
    return false;
  };
  
  // Interface selection
  const [activeTab, setActiveTab] = useState<'schedule' | 'my-bookings' | 'admin'>('schedule');
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [bookingNotes, setBookingNotes] = useState<string>('');
  const [isBookingInProgress, setIsBookingInProgress] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Validate Firestore Connection on load as per rules
  useEffect(() => {
    if (isFirebaseConfigured && db) {
      const testConnection = async () => {
        try {
          await getDocFromServer(doc(db, 'test', 'connection'));
        } catch (error) {
          if (error instanceof Error && error.message.includes('the client is offline')) {
            console.error("Please check your Firebase configuration.");
          }
        }
      };
      testConnection();
    }
  }, []);

  // Monitor Authentication state shift
  useEffect(() => {
    if (!auth) {
      setAuthLoading(false);
      return;
    }
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Live Sync ALL bookedSlots indicators globally
  useEffect(() => {
    if (!user || !db || !isFirebaseConfigured) return;

    setSlotsLoading(true);
    const slotQuery = query(
      collection(db, 'bookedSlots'),
      where('isBooked', '==', true)
    );

    const unsubscribe = onSnapshot(slotQuery, (snapshot) => {
      const list: BookedSlot[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as BookedSlot;
        list.push({ id: docSnap.id, ...data });
      });
      setGlobalBookedSlots(list);
      setSlotsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'bookedSlots');
      setSlotsLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  // Live Sync ALL customSlots globally
  useEffect(() => {
    if (!user || !db || !isFirebaseConfigured) return;

    const customQuery = query(collection(db, 'customSlots'));

    const unsubscribe = onSnapshot(customQuery, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() });
      });
      setGlobalCustomSlots(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'customSlots');
    });

    return () => unsubscribe();
  }, [user]);

  // Live Sync Calendar settings config document
  useEffect(() => {
    if (!user || !db || !isFirebaseConfigured) return;

    const settingsRef = doc(db, 'settings', 'calendar');
    const unsubscribe = onSnapshot(settingsRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setCalendarSettings({
          openDays: data.openDays || ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
          specialOpenDates: data.specialOpenDates || [],
          holidayDates: data.holidayDates || []
        });
      } else if (isAdminUser) {
        // Bootstrap default settings document atomically
        const batch = writeBatch(db);
        batch.set(settingsRef, {
          openDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
          specialOpenDates: [],
          holidayDates: []
        });
        batch.commit().catch(err => {
          console.error("Created default settings err:", err);
        });
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/calendar');
    });

    return () => unsubscribe();
  }, [user, isAdminUser]);

  // Live Sync current user's personal booking logs
  useEffect(() => {
    if (!user || !db || !isFirebaseConfigured) {
      setBookingsLoading(false);
      return;
    }

    setBookingsLoading(true);
    const bookingsQuery = query(
      collection(db, 'bookings'),
      where('userId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(bookingsQuery, (snapshot) => {
      const bookingsList: Booking[] = [];
      snapshot.forEach((docSnap) => {
        bookingsList.push({ id: docSnap.id, ...docSnap.data() } as Booking);
      });
      
      // Sort in-memory to prevent requiring composite index creation on Firebase side
      bookingsList.sort((a, b) => {
        const dateTimeA = new Date(`${a.date}T${a.slot}`).getTime();
        const dateTimeB = new Date(`${b.date}T${b.slot}`).getTime();
        return dateTimeB - dateTimeA; // descending order
      });
      
      setMyBookings(bookingsList);
      setBookingsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'bookings');
      setBookingsLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  // Live Sync ALL bookings (Admin only)
  useEffect(() => {
    if (!user || !db || !isFirebaseConfigured || !isAdminUser) {
      setAllBookings([]);
      setAllBookingsLoading(false);
      return;
    }

    setAllBookingsLoading(true);
    const allQ = query(collection(db, 'bookings'));

    const unsubscribe = onSnapshot(allQ, (snapshot) => {
      const bookingsList: Booking[] = [];
      snapshot.forEach((docSnap) => {
        bookingsList.push({ id: docSnap.id, ...docSnap.data() } as Booking);
      });
      
      bookingsList.sort((a, b) => {
        const dateTimeA = new Date(`${a.date}T${a.slot}`).getTime();
        const dateTimeB = new Date(`${b.date}T${b.slot}`).getTime();
        return dateTimeB - dateTimeA; // descending
      });
      
      setAllBookings(bookingsList);
      setAllBookingsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'bookings');
      setAllBookingsLoading(false);
    });

    return () => unsubscribe();
  }, [user, isAdminUser]);

  // Handle Google OAuth trigger
  const handleGoogleLogin = async () => {
    if (!auth) return;
    const provider = new GoogleAuthProvider();
    // Enforce account selection prompt
    provider.setCustomParameters({ prompt: 'select_account' });
    try {
      await signInWithPopup(auth, provider);
      triggerAlert('success', t.loginSuccessMessage);
    } catch (error) {
      console.error("Sign-in issue:", error);
      triggerAlert('error', t.googleLoginFailMessage);
    }
  };

  const handleLogout = async () => {
    if (!auth) return;
    try {
      await signOut(auth);
      setMyBookings([]);
      setGlobalBookedSlots([]);
      setGlobalCustomSlots([]);
      triggerAlert('success', t.logoutSuccessMessage);
    } catch (error) {
      console.error("Sign-out issue:", error);
    }
  };

  const triggerAlert = (type: 'success' | 'error', text: string) => {
    setStatusMessage({ type, text });
    setTimeout(() => {
      setStatusMessage(null);
    }, 5000);
  };

  // Admin Config helper: update Firestore settings values
  const handleUpdateCalendarSettings = async (updated: Partial<CalendarSettingsType>) => {
    if (!user || !db || !isAdminUser) return;
    setIsUpdatingSettings(true);
    try {
      const settingsRef = doc(db, 'settings', 'calendar');
      const batch = writeBatch(db);
      batch.set(settingsRef, {
        ...calendarSettings,
        ...updated
      }, { merge: true });
      await batch.commit();
      triggerAlert('success', lang === 'ur' ? 'ترتیبات کامیابی سے اپڈیٹ ہوگئیں!' : 'Settings updated successfully!');
    } catch (error) {
      console.error("Error setting configuration:", error);
      handleFirestoreError(error, OperationType.UPDATE, 'settings/calendar');
      triggerAlert('error', lang === 'ur' ? 'ترتیبات کو محفوظ کرنے میں ناکامی!' : 'Failed to update settings!');
    } finally {
      setIsUpdatingSettings(false);
    }
  };

  // Admin Config: Register specific override dates (special open / holiday close)
  const handleAddCustomDateSetting = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminCustomConfigDate || !user || !db || !isAdminUser) return;
    
    let updatedSpecial = [...calendarSettings.specialOpenDates];
    let updatedHoliday = [...calendarSettings.holidayDates];
    
    if (adminCustomConfigType === 'special') {
      updatedHoliday = updatedHoliday.filter(d => d !== adminCustomConfigDate);
      if (!updatedSpecial.includes(adminCustomConfigDate)) {
        updatedSpecial.push(adminCustomConfigDate);
      }
    } else {
      updatedSpecial = updatedSpecial.filter(d => d !== adminCustomConfigDate);
      if (!updatedHoliday.includes(adminCustomConfigDate)) {
        updatedHoliday.push(adminCustomConfigDate);
      }
    }
    
    await handleUpdateCalendarSettings({
      specialOpenDates: updatedSpecial,
      holidayDates: updatedHoliday
    });
    setAdminCustomConfigDate('');
  };

  // Admin Config: Deregister custom override dates
  const handleRemoveCustomDateSetting = async (dateStr: string, type: 'special' | 'holiday') => {
    if (!user || !db || !isAdminUser) return;
    if (type === 'special') {
      const updatedSpecial = calendarSettings.specialOpenDates.filter(d => d !== dateStr);
      await handleUpdateCalendarSettings({ specialOpenDates: updatedSpecial });
    } else {
      const updatedHoliday = calendarSettings.holidayDates.filter(d => d !== dateStr);
      await handleUpdateCalendarSettings({ holidayDates: updatedHoliday });
    }
  };

  // Perform Slot Booking Write-Batch (Atomic double-write)
  const bookSelectedSlot = async () => {
    if (!user || !db || !selectedSlot) return;

    // Double check that they do not already have an active appointment
    const hasActive = myBookings.some(b => b.status === "booked");
    if (hasActive) {
      triggerAlert('error', lang === 'ur' ? t.alreadyBookedTitle : "You already have an active appointment.");
      return;
    }

    // Double check if slot was booked by someone else
    if (busySlots[selectedSlot]) {
      const occupiedMsg = lang === 'ur'
        ? 'معذرت، یہ سلاٹ ابھی کسی اور نے بک کر لیا ہے۔ براہ کرم کوئی دوسرا وقت منتخب کریں۔'
        : 'Sorry, this slot was just booked by someone else. Please choose another slot.';
      triggerAlert('error', occupiedMsg);
      setSelectedSlot(null);
      return;
    }

    setIsBookingInProgress(true);
    const slotId = `${selectedDate}_${selectedSlot.replace(':', '-')}`;
    const bookingId = `${user.uid}_${selectedDate}_${selectedSlot.replace(':', '-')}`;

    try {
      const batch = writeBatch(db);

      // 1. Create Private details Booking
      const bookingRef = doc(db, 'bookings', bookingId);
      batch.set(bookingRef, {
        date: selectedDate,
        slot: selectedSlot,
        userId: user.uid,
        userName: user.displayName || 'صارف',
        userEmail: user.email || '',
        status: 'booked',
        notes: bookingNotes,
        createdAt: serverTimestamp()
      });

      // 2. Create Public Anonymous slot block marker
      const slotRef = doc(db, 'bookedSlots', slotId);
      batch.set(slotRef, {
        date: selectedDate,
        slot: selectedSlot,
        isBooked: true,
        userId: user.uid
      });

      await batch.commit();

      const successMsg = t.bookingSuccessMessage
        .replace('{slot}', getLocalizedSlotLabel(selectedSlot, lang))
        .replace('{date}', formatBilingualDate(selectedDate, lang));
      triggerAlert('success', successMsg);
      setSelectedSlot(null);
      setBookingNotes('');
    } catch (error) {
      console.error("Booking write error:", error);
      handleFirestoreError(error, OperationType.CREATE, `bookings/${bookingId}`);
      triggerAlert('error', t.bookingFailMessage);
    } finally {
      setIsBookingInProgress(false);
    }
  };

  // Reschedule Booking atomic transition
  const rescheduleSelectedBooking = async () => {
    if (!user || !db || !reschedulingBooking || !selectedSlot) return;

    // Double check if slot is already occupied
    if (busySlots[selectedSlot]) {
      const occupiedMsg = lang === 'ur'
        ? 'معذرت، یہ سلاٹ ابھی کسی اور نے بک کر لیا ہے۔ براہ کرم کوئی دوسرا وقت منتخب کریں۔'
        : 'Sorry, this slot was just booked by someone else. Please choose another slot.';
      triggerAlert('error', occupiedMsg);
      setSelectedSlot(null);
      return;
    }

    setIsBookingInProgress(true);
    const oldSlug = reschedulingBooking.slot.replace(':', '-');
    const oldBookingId = reschedulingBooking.id || `${reschedulingBooking.userId}_${reschedulingBooking.date}_${oldSlug}`;
    const oldSlotId = `${reschedulingBooking.date}_${oldSlug}`;

    const newSlug = selectedSlot.replace(':', '-');
    const targetUserId = reschedulingBooking.userId;
    const targetUserName = reschedulingBooking.userName;
    const targetUserEmail = reschedulingBooking.userEmail;
    
    const newBookingId = `${targetUserId}_${selectedDate}_${newSlug}`;
    const newSlotId = `${selectedDate}_${newSlug}`;

    try {
      const batch = writeBatch(db);

      // 1. Mark OLD booking as cancelled
      const oldBookingRef = doc(db, 'bookings', oldBookingId);
      batch.update(oldBookingRef, {
        status: 'cancelled'
      });

      // 2. Free up OLD public slot segment
      const oldSlotRef = doc(db, 'bookedSlots', oldSlotId);
      batch.delete(oldSlotRef);

      // 3. Create NEW booking
      const newBookingRef = doc(db, 'bookings', newBookingId);
      batch.set(newBookingRef, {
        date: selectedDate,
        slot: selectedSlot,
        userId: targetUserId,
        userName: targetUserName,
        userEmail: targetUserEmail,
        status: 'booked',
        notes: bookingNotes || reschedulingBooking.notes || '',
        createdAt: serverTimestamp()
      });

      // 4. Create NEW public slot marker
      const newSlotRef = doc(db, 'bookedSlots', newSlotId);
      batch.set(newSlotRef, {
        date: selectedDate,
        slot: selectedSlot,
        isBooked: true,
        userId: targetUserId
      });

      await batch.commit();

      triggerAlert('success', t.rescheduleSuccess || "Appointment successfully rescheduled!");
      setReschedulingBooking(null);
      setSelectedSlot(null);
      setBookingNotes('');
    } catch (error) {
      console.error("Reschedule failure:", error);
      handleFirestoreError(error, OperationType.UPDATE, `bookings/${oldBookingId}`);
      triggerAlert('error', lang === 'ur' ? "مقررہ وقت کی تبدیلی میں خرابی پیش آئی۔" : "Failed to reschedule the appointment.");
    } finally {
      setIsBookingInProgress(false);
    }
  };

  // Cancel Booking (Soft cancel in booking + delete public availability block)
  const cancelBooking = async (booking: Booking) => {
    if (!user || !db) return;

    // Check 3 hour restriction (bypass for admin)
    if (!isAdminUser) {
      const [year, month, day] = booking.date.split('-').map(Number);
      const [hour, minute] = booking.slot.split(':').map(Number);
      const appointmentDate = new Date(year, month - 1, day, hour, minute);
      const appointmentTime = appointmentDate.getTime();
      const nowTime = new Date().getTime();
      const hoursDiff = (appointmentTime - nowTime) / (1000 * 60 * 60);

      if (hoursDiff < 3) {
        triggerAlert('error', t.hoursLimitError);
        return;
      }
    }

    setConfirmDialog({
      isOpen: true,
      title: lang === 'ur' ? 'اپائنٹمنٹ منسوخ کریں؟' : 'Cancel Appointment?',
      message: t.cancelAppointmentConfirm,
      onConfirm: async () => {
        const slug = booking.slot.replace(':', '-');
        const bookingId = booking.id || `${booking.userId || user.uid}_${booking.date}_${slug}`;
        const slotId = `${booking.date}_${slug}`;

        try {
          const batch = writeBatch(db);

          // Update booking state to cancelled
          const bookingRef = doc(db, 'bookings', bookingId);
          batch.update(bookingRef, {
            status: 'cancelled'
          });

          // Wipe public blocking marker to re-enable slot for other users
          const slotRef = doc(db, 'bookedSlots', slotId);
          batch.delete(slotRef);

          await batch.commit();
          triggerAlert('success', t.cancelSuccessMessage);
        } catch (error) {
          console.error("Cancellation error:", error);
          handleFirestoreError(error, OperationType.UPDATE, `bookings/${bookingId}`);
          triggerAlert('error', t.cancelFailMessage);
        } finally {
          setConfirmDialog(null);
        }
      }
    });
  };

  // Admin Action: Create Custom Slot
  const handleAdminCreateSlot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !db || !isAdminUser || !adminSelectedDate || !adminSelectedTime) return;

    setIsAdminCreatingSlot(true);
    const slotId = `${adminSelectedDate}_${adminSelectedTime.replace(':', '-')}`;

    try {
      const slotRef = doc(db, 'customSlots', slotId);
      const batch = writeBatch(db);
      batch.set(slotRef, {
        date: adminSelectedDate,
        slot: adminSelectedTime,
        createdBy: user.uid
      });
      await batch.commit();

      triggerAlert('success', t.slotAddedSuccess);
      // Reset selected time
      setAdminSelectedTime('09:00');
    } catch (error) {
      console.error("Custom slot creation error:", error);
      handleFirestoreError(error, OperationType.CREATE, `customSlots/${slotId}`);
      triggerAlert('error', t.bookingFailMessage);
    } finally {
      setIsAdminCreatingSlot(false);
    }
  };

  // Admin Action: Delete Custom Slot
  const handleAdminDeleteCustomSlot = async (slotId: string) => {
    if (!user || !db || !isAdminUser) return;
    const confirmMsg = lang === 'ur' ? 'کیا آپ واقعی اس ٹائم سلاٹ کو ختم کرنا چاہتے ہیں؟' : 'Are you sure you want to remove this custom slot?';
    
    setConfirmDialog({
      isOpen: true,
      title: lang === 'ur' ? 'سلاٹ ختم کریں؟' : 'Remove Slot?',
      message: confirmMsg,
      onConfirm: async () => {
        try {
          const slotRef = doc(db, 'customSlots', slotId);
          const batch = writeBatch(db);
          batch.delete(slotRef);
          await batch.commit();
          triggerAlert('success', t.slotDeletedSuccess);
        } catch (error) {
          console.error("Custom slot delete error:", error);
          handleFirestoreError(error, OperationType.DELETE, `customSlots/${slotId}`);
        } finally {
          setConfirmDialog(null);
        }
      }
    });
  };

  // Admin Action: Cancel user booking
  const adminCancelBooking = async (booking: Booking) => {
    if (!user || !db || !isAdminUser) return;
    
    setConfirmDialog({
      isOpen: true,
      title: lang === 'ur' ? 'اپائنٹمنٹ منسوخ کریں؟' : 'Cancel Appointment?',
      message: t.cancelAnyBookingConfirm,
      onConfirm: async () => {
        const slug = booking.slot.replace(':', '-');
        const bookingId = booking.id;
        const slotId = `${booking.date}_${slug}`;

        try {
          const batch = writeBatch(db);

          // Update booking state to cancelled
          const bookingRef = doc(db, 'bookings', bookingId);
          batch.update(bookingRef, {
            status: 'cancelled'
          });

          // Wipe public blocking marker to re-enable slot for other users
          const slotRef = doc(db, 'bookedSlots', slotId);
          batch.delete(slotRef);

          await batch.commit();
          triggerAlert('success', t.cancelSuccessMessage);
        } catch (error) {
          console.error("Admin cancellation error:", error);
          handleFirestoreError(error, OperationType.UPDATE, `bookings/${bookingId}`);
          triggerAlert('error', t.cancelFailMessage);
        } finally {
          setConfirmDialog(null);
        }
      }
    });
  };

  // Convert custom chosen date state to selector array format
  const handleCustomDateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customDateValue) return;

    // Validate if the chosen manual date is selectable (is open)
    const dateObj = new Date(customDateValue);
    const dayOfWeekName = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][dateObj.getDay()];
    
    const isDayWeekOpen = calendarSettings.openDays.includes(dayOfWeekName);
    const isSpecialOpenStr = calendarSettings.specialOpenDates.includes(customDateValue);
    const isHolidayStr = calendarSettings.holidayDates.includes(customDateValue);
    const isDayOpen = (isDayWeekOpen || isSpecialOpenStr) && !isHolidayStr;

    if (!isDayOpen && !isAdminUser) {
      triggerAlert('error', lang === 'ur' ? 'معذرت، کیلنڈر اس تاریخ کو بند ہے!' : 'Sorry, the calendar is closed on this date!');
      return;
    }

    setSelectedDate(customDateValue);
    setSelectedSlot(null);
    setShowCustomDatePicker(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 antialiased selection:bg-blue-100 selection:text-blue-900" id="app_root" dir={isRtl ? "rtl" : "ltr"}>
      
      {/* Toast Alert Notifications */}
      <AnimatePresence>
        {statusMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className={`fixed top-4 left-4 right-4 md:left-auto md:right-6 md:w-96 z-50 p-4 rounded-xl shadow-xl flex items-start gap-3 border ${
              statusMessage.type === 'success' 
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900 shadow-emerald-100/50' 
              : 'bg-red-50 border-red-200 text-red-900 shadow-red-100/50'
            }`}
            id="toast_message"
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <XCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            )}
            <div className={`flex-1 text-sm font-medium leading-relaxed ${isRtl ? 'text-right' : 'text-left'}`}>
              {statusMessage.text}
            </div>
            <button 
              className="text-slate-400 hover:text-slate-600 font-bold ml-2 text-xs"
              onClick={() => setStatusMessage(null)}
            >
              ✕
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Interactive Custom Confirm Dialog Modal */}
      <AnimatePresence>
        {confirmDialog && confirmDialog.isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="confirm_modal_container">
            {/* Backdrop with transition */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setConfirmDialog(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />

            {/* Modal card */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className="relative w-full max-w-md bg-white rounded-3xl p-6 md:p-8 shadow-2xl border border-slate-100 flex flex-col gap-5 z-10 animate-fade-in"
              dir={isRtl ? "rtl" : "ltr"}
            >
              <div className="flex items-center gap-3 border-b border-slate-50 pb-3">
                <div className="w-10 h-10 bg-red-50 rounded-full flex items-center justify-center text-red-600 shrink-0">
                  <AlertCircle className="w-5.5 h-5.5" />
                </div>
                <div>
                  <h3 className="text-lg font-extrabold text-slate-950 p-0 m-0 leading-tight">
                    {confirmDialog.title}
                  </h3>
                </div>
              </div>

              <p className="text-sm text-slate-650 leading-relaxed font-semibold">
                {confirmDialog.message}
              </p>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => setConfirmDialog(null)}
                  className="px-5 py-2.5 rounded-2xl text-xs font-extrabold bg-slate-100 hover:bg-slate-200 text-slate-600 transition-all border border-slate-200 cursor-pointer"
                >
                  {lang === 'ur' ? 'رد کریں' : 'Cancel'}
                </button>
                <button
                  onClick={confirmDialog.onConfirm}
                  className="px-6 py-2.5 rounded-2xl text-xs font-extrabold bg-red-600 hover:bg-red-700 text-white transition-all shadow-md shadow-red-100 cursor-pointer"
                >
                  {lang === 'ur' ? 'جی ہاں، تصدیق کریں' : 'Yes, Confirm'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Header */}
      <header className="sticky top-0 z-40 bg-white border-b border-blue-50/80 shadow-xs shadow-blue-50/30" id="app_header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between" dir={isRtl ? "rtl" : "ltr"}>
          
          {/* Logo / Brand Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-blue-200">
              <CalendarRange className="w-5.5 h-5.5" />
            </div>
            <div className={isRtl ? "text-right" : "text-left"}>
              <h1 className="text-xl font-bold text-blue-950 tracking-tight">{t.title}</h1>
              <p className="text-xs text-blue-500 font-medium">{t.subtitle}</p>
            </div>
          </div>

          {/* User & Language Section */}
          <div className="flex items-center gap-4" dir={isRtl ? "ltr" : "rtl"}>
            {/* Language Selector Selector */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl shadow-xs" id="language_switcher" dir="ltr">
              <button 
                onClick={() => setLang('ur')} 
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  lang === 'ur' 
                  ? 'bg-blue-600 text-white shadow-xs' 
                  : 'bg-transparent text-slate-500 hover:text-slate-700'
                }`}
                id="lang_ur_btn"
              >
                اردو
              </button>
              <button 
                onClick={() => setLang('en')} 
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  lang === 'en' 
                  ? 'bg-blue-600 text-white shadow-xs' 
                  : 'bg-transparent text-slate-500 hover:text-slate-700'
                }`}
                id="lang_en_btn"
              >
                English
              </button>
            </div>

            {user ? (
              <div className="flex items-center gap-2.5 bg-slate-50 border border-slate-100 p-1.5 pr-3.5 pl-3.5 rounded-full">
                <span className="hidden sm:inline-block text-xs font-semibold text-slate-700">{user.displayName || (isRtl ? 'صارف' : 'User')}</span>
                {user.photoURL ? (
                  <img src={user.photoURL} alt="Avatar" className="w-8 h-8 rounded-full border border-blue-200" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700">
                    <User className="w-4.5 h-4.5" />
                  </div>
                )}
                <button 
                  onClick={handleLogout}
                  title={t.logoutTitle} 
                  className="p-1.5 text-slate-400 hover:text-red-600 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
                  id="header_logout_btn"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <span className="text-xs font-semibold text-blue-600 hidden sm:inline-block pr-1">{t.welcome}</span>
            )}
          </div>
        </div>
      </header>

      {/* Top Warning if Firebase configuration is pending setup */}
      {!isFirebaseConfigured && (
        <div className="bg-yellow-50 border-b border-yellow-200/50 py-3.5 px-4" id="firebase_warning">
          <div className="max-w-4xl mx-auto flex items-center gap-3">
            <AlertCircle className="w-5.5 h-5.5 text-yellow-700 shrink-0" />
            <p className={`text-sm font-medium text-yellow-900 leading-relaxed w-full ${isRtl ? 'text-right' : 'text-left'}`}>
              <strong className="text-yellow-950 font-bold block sm:inline-block mr-1 ml-1">{t.firebaseWarningTitle}</strong> {t.firebaseWarningDesc}
            </p>
          </div>
        </div>
      )}

      {/* Hero Banner / Introduction if auth is ready */}
      {authLoading ? (
        <div className="flex flex-col items-center justify-center min-h-[60vh] py-24 px-4" id="loading_spinner">
          <div className="relative flex items-center justify-center mb-6">
            {/* Pulsing light behind the spinner for a soft glow */}
            <div className="absolute w-20 h-20 bg-blue-100 rounded-full animate-ping opacity-40"></div>
            <div className="relative w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg border border-blue-50">
              <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
            </div>
          </div>
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center space-y-1"
          >
            <p className="text-sm font-extrabold text-blue-950 tracking-wide">{t.loading}</p>
            <p className="text-[11px] font-semibold text-slate-400">Please prepare your scheduling view...</p>
          </motion.div>
        </div>
      ) : !user ? (
        
        /* 1. LOGIN LANDING PANEL */
        <main className="max-w-md mx-auto px-4 py-16 sm:py-24" id="login_panel">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl p-8 shadow-xl shadow-blue-100/50 border border-slate-100 text-center"
          >
            <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-6 text-blue-600">
              <CalendarDays className="w-9 h-9" />
            </div>

            <h2 className="text-2xl font-bold text-slate-900 tracking-tight mb-2 leading-snug">{t.loginTitle}</h2>
            <p className="text-slate-500 text-sm leading-relaxed mb-8 max-w-xs mx-auto">
              {t.loginDesc}
            </p>

            <div className="space-y-4">
              <button 
                onClick={handleGoogleLogin}
                className="w-full h-13 cursor-pointer bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-md shadow-blue-200/80 hover:shadow-lg hover:shadow-blue-200 font-bold transition-all flex items-center justify-center gap-3.5"
                id="google_login_btn"
              >
                {/* Embedded High-Quality Vector Google G Icon SVG */}
                <svg className="w-5 h-5 bg-white p-1 rounded-full text-slate-800" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.62-.63-1.07-1.37-1.35-2.18z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                {t.googleLogin}
              </button>
              
              <div className="pt-2 text-center">
                <span className="text-[11px] text-slate-400 font-medium">{t.loginTerms}</span>
              </div>
            </div>
          </motion.div>
        </main>

      ) : (

        /* 2. DURATION SCHEDULER & BOOKING PLATFORM */
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" id="dashboard_panel">
          
          <div className="flex flex-col gap-6">
            
            {/* Top Navigation Tabs */}
            <div className="flex items-center justify-between border-b border-slate-200">
              <div className={`flex gap-4 w-full ${isRtl ? 'justify-start' : 'justify-start'}`}>
                <button 
                  onClick={() => setActiveTab('schedule')}
                  className={`py-3.5 px-4 font-bold text-sm tracking-tight border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
                    activeTab === 'schedule' 
                    ? 'border-blue-600 text-blue-600' 
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                  id="tab_schedule"
                >
                  <CalendarDays className="w-4 h-4" />
                  {t.schedulerTab}
                </button>
                <button 
                  onClick={() => setActiveTab('my-bookings')}
                  className={`py-3.5 px-4 font-bold text-sm tracking-tight border-b-2 transition-all flex items-center gap-2 relative cursor-pointer ${
                    activeTab === 'my-bookings' 
                    ? 'border-blue-600 text-blue-600' 
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                  id="tab_my_bookings"
                >
                  <BookmarkCheck className="w-4 h-4" />
                  {t.myBookingsTab}
                  {myBookings.filter(b => b.status === 'booked').length > 0 && (
                    <span className="absolute top-1 -right-1 bg-blue-600 text-white text-[10px] h-4 w-4 rounded-full flex items-center justify-center font-bold">
                      {myBookings.filter(b => b.status === 'booked').length}
                    </span>
                  )}
                </button>
                {isAdminUser && (
                  <button 
                    onClick={() => setActiveTab('admin')}
                    className={`py-3.5 px-4 font-bold text-sm tracking-tight border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
                      activeTab === 'admin' 
                      ? 'border-blue-600 text-blue-600' 
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                    }`}
                    id="tab_admin"
                  >
                    <Lock className="w-4 h-4 text-blue-600" />
                    {t.adminPanelTab}
                  </button>
                )}
              </div>
            </div>

            {/* A. SCHEDULER TAB CONTENT */}
            {activeTab === 'schedule' && (() => {
              const activeBooking = myBookings.find(bk => bk.status === 'booked');
              
              if (activeBooking && !reschedulingBooking) {
                return (
                  <div className="col-span-1 md:col-span-3 space-y-6" id="dashboard_locked_state">
                    {/* Vivid informational block */}
                    <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-3xl p-6 md:p-8 text-white shadow-xl relative overflow-hidden" id="active_booking_alert">
                      <div className="absolute right-0 bottom-0 opacity-10 transform translate-x-12 translate-y-12">
                        <BookmarkCheck className="w-96 h-96" />
                      </div>
                      
                      <div className="max-w-xl space-y-4">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 text-white rounded-full text-xs font-bold uppercase tracking-widest leading-none">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {lang === 'ur' ? 'فعال تصدیق شدہ بُکنگ' : 'Active Confirmed Appointment'}
                        </span>
                        <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight leading-tight">
                          {t.alreadyBookedTitle}
                        </h2>
                        <p className="text-sm text-emerald-50/90 leading-relaxed font-semibold">
                          {t.alreadyBookedDesc}
                        </p>
                      </div>
                    </div>

                    {/* Styled tickets view of the slot */}
                    <div className="bg-white rounded-3xl p-6 md:p-8 border border-slate-150 shadow-md relative overflow-hidden" id="active_booking_ticket">
                      <div className="absolute top-0 bottom-0 left-0 w-2.5 bg-blue-600" />
                      
                      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                        <div className="space-y-5 flex-1">
                          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                            <div>
                              <span className="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">{lang === 'ur' ? 'مقررہ تاریخ' : 'SCHEDULED DATE'}</span>
                              <span className="text-base font-extrabold text-slate-900 leading-snug">
                                {formatBilingualDate(activeBooking.date, lang)}
                              </span>
                            </div>

                            <div>
                              <span className="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">{lang === 'ur' ? 'منتخب ٹائم سلاٹ' : 'TIME SLOT'}</span>
                              <span className="text-base font-extrabold text-blue-600 flex items-center gap-1.5 leading-snug">
                                <Clock className="w-5 h-5 text-blue-500 shrink-0" />
                                {getLocalizedSlotLabel(activeBooking.slot, lang)}
                              </span>
                            </div>

                            <div>
                              <span className="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">{lang === 'ur' ? 'مریض / درخواست دہندہ' : 'APPLICANT'}</span>
                              <span className="text-base font-extrabold text-slate-900 leading-snug">
                                {activeBooking.userName}
                              </span>
                            </div>
                          </div>

                          {activeBooking.notes && (
                            <div className="text-xs bg-slate-50 border border-slate-100 p-4.5 rounded-2xl max-w-2xl text-left">
                              <span className="block text-[9px] font-extrabold text-blue-800 uppercase tracking-widest mb-1">{lang === 'ur' ? 'آپ کا پیغام / نوٹ' : 'YOUR NOTES / MESSAGE'}</span>
                              <p className="font-semibold text-slate-700 italic">"{activeBooking.notes}"</p>
                            </div>
                          )}

                          <div className="flex items-start gap-2 text-xs text-slate-500 max-w-xl">
                            <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                            <span>
                              {lang === 'ur' 
                                ? 'نوٹ: آپ اس بکنگ کو وقت مقررہ سے کم از کم 3 گھنٹے پہلے تبدیل یا منسوخ کر سکتے ہیں۔' 
                                : 'Note: You can cancel or reschedule this appointment up to 3 hours prior.'}
                            </span>
                          </div>
                        </div>

                        <div className="shrink-0 flex flex-col sm:flex-row gap-3">
                          <button
                            onClick={() => {
                              // Check 3 hour restriction (unless admin)
                              if (!isAdminUser) {
                                const [year, month, day] = activeBooking.date.split('-').map(Number);
                                const [hour, minute] = activeBooking.slot.split(':').map(Number);
                                const appointmentDate = new Date(year, month - 1, day, hour, minute);
                                const appointmentTime = appointmentDate.getTime();
                                const nowTime = new Date().getTime();
                                const hoursDiff = (appointmentTime - nowTime) / (1000 * 60 * 60);

                                if (hoursDiff < 3) {
                                  triggerAlert('error', t.rescheduleLimitError);
                                  return;
                                }
                              }
                              setReschedulingBooking(activeBooking);
                              setSelectedDate(activeBooking.date);
                              setSelectedSlot(null);
                            }}
                            className="px-6 py-3 cursor-pointer bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-2xl text-xs transition-all shadow-md shadow-blue-100"
                          >
                            {t.rescheduleBtn}
                          </button>
                          <button
                            onClick={() => cancelBooking(activeBooking)}
                            className="px-6 py-3 cursor-pointer bg-red-50 hover:bg-red-100 text-red-650 hover:text-red-700 font-extrabold rounded-2xl text-xs transition-all border border-red-100/70"
                          >
                            {t.cancelAppointmentBtn}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }

              const calData = getDaysInMonthObj(currentMonthDate);
              const currentMonthName = lang === 'ur' ? MONTH_NAMES_UR[calData.month] : MONTH_NAMES_EN[calData.month];
              
              const handlePrevMonth = () => {
                setCurrentMonthDate(prev => {
                  const d = new Date(prev);
                  d.setMonth(d.getMonth() - 1);
                  return d;
                });
              };

              const handleNextMonth = () => {
                setCurrentMonthDate(prev => {
                  const d = new Date(prev);
                  d.setMonth(d.getMonth() + 1);
                  return d;
                });
              };

              // Compute all available sorted slots
              const allAvailableSlots = [...TIME_SLOTS];
              customSlots.forEach(cs => {
                if (!allAvailableSlots.some(s => s.time === cs.slot)) {
                  allAvailableSlots.push({
                    time: cs.slot,
                    label: getSlotTimeOnly(cs.slot)
                  });
                }
              });
              allAvailableSlots.sort((a, b) => a.time.localeCompare(b.time));

              return (
                <div className="space-y-6 w-full" id="schedule_tab_root">
                  {reschedulingBooking && (
                    <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-3xl p-6 md:p-8 text-white shadow-xl relative overflow-hidden" id="rescheduling_banner_top">
                      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                        <div className="space-y-2">
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 text-white rounded-full text-[10px] font-bold uppercase tracking-widest leading-none">
                            🔄 {lang === 'ur' ? 'تبدیلی وقت کا موڈ' : 'Rescheduling Mode'}
                          </span>
                          <h2 className="text-xl md:text-2xl font-extrabold tracking-tight leading-none">
                            {t.rescheduleBanner}
                          </h2>
                          <p className="text-sm text-blue-100 font-semibold">
                            {lang === 'ur'
                              ? `موجودہ بکنگ: ${formatBilingualDate(reschedulingBooking.date, lang)} بوقت ${getLocalizedSlotLabel(reschedulingBooking.slot, lang)}`
                              : `Original Booking: ${formatBilingualDate(reschedulingBooking.date, lang)} at ${getLocalizedSlotLabel(reschedulingBooking.slot, lang)}`}
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            setReschedulingBooking(null);
                            setSelectedSlot(null);
                          }}
                          className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-extrabold rounded-2xl text-xs transition-all shadow-md cursor-pointer border border-red-500/30 shrink-0"
                        >
                          {t.cancelReschedule}
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 w-full" id="active_schedule_picker_area">
                  
                  {/* Area 1: Google Style Calendar Date selection + Dropdown time selection */}
                  <div className="lg:col-span-2 space-y-6">
                    
                    {/* Fancy Google Calendar card layout selection */}
                    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-5">
                      <div className="flex items-center justify-between border-b border-slate-50 pb-3">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-5.5 h-5.5 text-blue-600 animate-pulse" />
                          <h3 className="font-extrabold text-slate-900 text-base">{t.selectDateTitle}</h3>
                        </div>
                        <span className="text-[11px] font-bold text-slate-400 bg-slate-50 border border-slate-100 px-3 py-1 rounded-full uppercase tracking-wider font-mono">
                          Google Calendar Interface
                        </span>
                      </div>

                      {/* Google Calendar view layout */}
                      <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100 max-w-xl mx-auto md:mx-0">
                        {/* Header navigation bar */}
                        <div className="flex items-center justify-between mb-5">
                          <button
                            onClick={handlePrevMonth}
                            className="w-10 h-10 flex items-center justify-center hover:bg-slate-200 rounded-full cursor-pointer transition-colors text-slate-700 font-bold text-lg"
                            type="button"
                          >
                            ←
                          </button>
                          <span className="font-extrabold text-sm md:text-base text-slate-800 tracking-tight">
                            {currentMonthName} {calData.year}
                          </span>
                          <button
                            onClick={handleNextMonth}
                            className="w-10 h-10 flex items-center justify-center hover:bg-slate-200 rounded-full cursor-pointer transition-colors text-slate-700 font-bold text-lg"
                            type="button"
                          >
                            →
                          </button>
                        </div>

                        {/* Weekday indicator grid header columns */}
                        <div className="grid grid-cols-7 gap-1 text-center mb-3">
                          {(lang === 'ur' ? WEEKDAYS_UR : WEEKDAYS_EN).map((wd) => (
                            <span key={wd} className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest text-center">
                              {wd}
                            </span>
                          ))}
                        </div>

                        {/* Calendar days cells map */}
                        <div className="grid grid-cols-7 gap-y-1.5 gap-x-1 justify-items-center">
                          {/* Empties padding before start of month weekdays */}
                          {Array.from({ length: calData.startDayOfWeek }).map((_, idx) => (
                            <div key={`blank_cell_${idx}`} className="h-10 w-10 sm:h-11 sm:w-11" />
                          ))}

                                                  {/* Live Calendar Month Days */}
                          {calData.days.map((day) => {
                            const isChosen = selectedDate === day.dateString;
                            const isToday = (() => {
                              const todayObj = new Date();
                              const todayStr = `${todayObj.getFullYear()}-${String(todayObj.getMonth() + 1).padStart(2, '0')}-${String(todayObj.getDate()).padStart(2, '0')}`;
                              return todayStr === day.dateString;
                            })();

                            const hasUserBookingOnThisDay = myBookings.some(b => b.date === day.dateString && b.status === 'booked');

                            const isDayOpen = (() => {
                              if (day.isPast) return false;
                              
                              const dateObj = new Date(day.dateString);
                              const dayOfWeekName = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][dateObj.getDay()];
                              
                              const isDayWeekOpen = calendarSettings.openDays.includes(dayOfWeekName);
                              const isSpecialOpenStr = calendarSettings.specialOpenDates.includes(day.dateString);
                              const isHolidayStr = calendarSettings.holidayDates.includes(day.dateString);
                              
                              return (isDayWeekOpen || isSpecialOpenStr) && !isHolidayStr;
                            })();

                            const availableSlotsCount = (() => {
                              if (!isDayOpen) return 0;
                              
                              const dailySlots = [...TIME_SLOTS];
                              globalCustomSlots.forEach(cs => {
                                if (cs.date === day.dateString && !dailySlots.some(s => s.time === cs.slot)) {
                                  dailySlots.push({
                                    time: cs.slot,
                                    label: getSlotTimeOnly(cs.slot)
                                  });
                                }
                              });
                              
                              const bookedForDate = globalBookedSlots
                                .filter(b => b.date === day.dateString && b.isBooked)
                                .map(b => b.slot);
                                
                              return dailySlots.filter(ts => {
                                const isTaken = bookedForDate.includes(ts.time);
                                const isPastSlot = checkIsPastSlot(ts.time, day.dateString);
                                return !isTaken && !isPastSlot;
                              }).length;
                            })();

                            const tooltipMsg = (() => {
                              if (day.isPast) {
                                return lang === 'ur' ? 'یہ تاریخ گزر چکی ہے' : 'This date has passed';
                              }
                              if (!isDayOpen) {
                                return lang === 'ur' ? 'تعطیل / بند ہے' : 'Closed / Holiday';
                              }
                              if (availableSlotsCount === 0) {
                                return lang === 'ur' ? 'تمام سلاٹس بکڈ ہیں' : 'All slots fully booked';
                              }
                              return lang === 'ur' 
                                ? `${availableSlotsCount} ٹائم سلاٹس دستیاب ہیں` 
                                : `${availableSlotsCount} slots available. Click to select!`;
                            })();

                            return (
                              <div key={day.dateString} className="relative group flex flex-col items-center justify-center">
                                <button
                                  onClick={() => {
                                    if (!day.isPast && isDayOpen) {
                                      setSelectedDate(day.dateString);
                                      setSelectedSlot(null); // Reset selection
                                      setCustomDateValue('');
                                    }
                                  }}
                                  type="button"
                                  disabled={day.isPast || !isDayOpen}
                                  className={`h-11 w-11 sm:h-12 sm:w-12 rounded-full flex flex-col items-center justify-center relative transition-all focus:outline-none ${
                                    day.isPast
                                      ? 'text-slate-350 bg-transparent cursor-not-allowed line-through opacity-40'
                                      : !isDayOpen
                                      ? 'bg-rose-50/20 border border-dashed border-red-100 text-slate-350 cursor-not-allowed opacity-55'
                                      : isChosen
                                      ? 'bg-blue-600 text-white shadow-md shadow-blue-200/80 font-extrabold scale-105'
                                      : isToday
                                      ? 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 font-extrabold'
                                      : 'bg-white border border-slate-100 text-slate-700 hover:bg-blue-50/50 hover:border-blue-200 cursor-pointer shadow-xs'
                                  }`}
                                  id={`cal_day_${day.dateString}`}
                                >
                                  <span className="text-xs leading-none font-extrabold mt-0.5">{day.dayNum}</span>
                                  
                                  {/* Available count label directly under date */}
                                  {!day.isPast && (
                                    <span className={`text-[7px] font-extrabold block leading-none transform scale-90 mb-0.5 mt-0.5 ${
                                      isChosen ? 'text-blue-100' : isDayOpen && availableSlotsCount > 0 ? 'text-blue-600' : 'text-slate-400'
                                    }`}>
                                      {isDayOpen ? (
                                        availableSlotsCount > 0 ? `${availableSlotsCount} ${lang === 'ur' ? 'خالی' : 'Free'}` : (lang === 'ur' ? 'بکڈ' : 'Full')
                                      ) : (
                                        lang === 'ur' ? 'تعطیل' : 'Closed'
                                      )}
                                    </span>
                                  )}

                                  {/* Small personal booking ping indicator underneath */}
                                  {!day.isPast && hasUserBookingOnThisDay && (
                                    <div className="flex gap-0.5 justify-center absolute bottom-1 h-1 w-full">
                                      <span className={`w-1 h-1 rounded-full ${isChosen ? 'bg-white' : 'bg-red-500 animate-ping'}`} />
                                    </div>
                                  )}
                                </button>

                                {/* Aesthetic CSS Tooltip on Hover */}
                                <div className="invisible group-hover:visible absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-slate-900/95 text-white text-[9px] md:text-xs font-bold py-1.5 px-3 rounded-xl shadow-xl z-20 whitespace-nowrap pointer-events-none transition-all opacity-0 group-hover:opacity-100">
                                  {tooltipMsg}
                                  <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-900" />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Manual text-input fallback date picker form */}
                      <div className="pt-2 border-t border-slate-50 flex items-center justify-between">
                        <button 
                          onClick={() => setShowCustomDatePicker(!showCustomDatePicker)}
                          className="text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1.5 rounded-lg hover:bg-blue-100 transition-colors cursor-pointer"
                          id="custom_date_toggle"
                        >
                          {showCustomDatePicker ? t.sliderToggle : t.customDateToggle}
                        </button>
                      </div>

                      {showCustomDatePicker && (
                        <motion.form 
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          onSubmit={handleCustomDateSubmit}
                          className="p-4 bg-slate-50 rounded-2xl flex flex-wrap gap-3 items-end"
                          id="date_form"
                        >
                          <div className="flex-1 min-w-[200px]">
                            <label className={`block text-xs font-bold text-slate-500 mb-1.5 ${isRtl ? 'text-right' : 'text-left'}`}>{t.customDateLabel}</label>
                            <input 
                              type="date" 
                              min={upcomingDays[0].dateString}
                              value={customDateValue || selectedDate}
                              onChange={(e) => setCustomDateValue(e.target.value)}
                              className="w-full bg-white border border-slate-200 p-2.5 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500"
                              id="custom_date_input"
                              required
                            />
                          </div>
                          <button 
                            type="submit" 
                            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm shadow-md shadow-blue-100 transition-all cursor-pointer"
                            id="date_submit_btn"
                          >
                            {t.lockDateButton}
                          </button>
                        </motion.form>
                      )}

                      {/* Active Selected Date banner */}
                      <div className="p-3 bg-blue-50/50 rounded-2xl text-center border border-blue-50/35">
                        <span className="text-xs text-blue-800 font-medium tracking-wide">
                          {t.activeDateBanner} <strong className="font-bold text-sm text-blue-900">{formatBilingualDate(selectedDate, lang)}</strong>
                        </span>
                      </div>
                    </div>

                    {/* Time Slots drop-down selecbox list */}
                    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-5" id="dropdown_slots_card">
                      <div className="flex items-center gap-2 border-b border-slate-50 pb-3">
                        <Clock className="w-5.5 h-5.5 text-blue-600" />
                        <h3 className="font-extrabold text-slate-900 text-base">{t.timeSlotsTitle}</h3>
                      </div>

                      {slotsLoading ? (
                        <div className="flex items-center gap-3 bg-slate-50 p-6 rounded-2xl animate-pulse">
                          <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                          <span className="text-sm font-bold text-slate-400">{lang === 'ur' ? 'ٹائم لسٹ تیار ہو رہی ہے...' : 'Preparing time slots...'}</span>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {(() => {
                            const selectableSlots = allAvailableSlots.filter((ts) => {
                              const lookup = busySlots[ts.time];
                              const isTaken = lookup !== undefined;
                              const isPastSlot = checkIsPastSlot(ts.time);
                              return !isTaken && !isPastSlot;
                            });

                            if (selectableSlots.length === 0) {
                              return (
                                <div className="p-5 bg-orange-50 rounded-2xl border border-orange-100 flex items-start gap-3">
                                  <AlertCircle className="w-5 h-5 text-orange-600 shrink-0 mt-0.5" />
                                  <div>
                                    <h4 className="font-bold text-orange-800 text-xs">
                                      {lang === 'ur' ? 'معذرت، کوئی ٹائم سلاٹ دستیاب نہیں ہے' : 'No available slots left'}
                                    </h4>
                                    <p className="text-[11px] text-orange-700 font-semibold mt-1">
                                      {lang === 'ur'
                                        ? 'اس تاریخ کے تمام سلاٹس بک ہو چکے ہیں یا ان کا وقت گزر چکا ہے۔ براہ کرم کوئی اور تاریخ منتخب کریں۔'
                                        : 'All of the time slots for this date are fully reserved or have passed. Please select another date from the calendar.'}
                                    </p>
                                  </div>
                                </div>
                              );
                            }

                            return (
                              <>
                                <label htmlFor="slot_select_box" className="block text-xs font-extrabold text-slate-400 uppercase tracking-widest leading-none">
                                  {lang === 'ur' ? 'ٹائم سلاٹ کا انتخاب کریں:' : 'CHOOSE APPOINTMENT TIME:'}
                                </label>
                                
                                <div className="relative">
                                  <select
                                    id="slot_select_box"
                                    value={selectedSlot || ''}
                                    onChange={(e) => {
                                      const val = e.target.value;
                                      setSelectedSlot(val ? val : null);
                                    }}
                                    className="w-full bg-slate-50 border border-slate-250 p-4.5 rounded-2xl text-sm font-extrabold text-slate-800 focus:outline-none focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 transition-all appearance-none cursor-pointer"
                                  >
                                    <option value="">
                                      {lang === 'ur' ? '--- ٹائم منتخب کریں ---' : '--- Choose Time Slot ---'}
                                    </option>
                                    {selectableSlots.map((ts) => {
                                      return (
                                        <option
                                          key={ts.time}
                                          value={ts.time}
                                          className="text-slate-800 font-extrabold"
                                        >
                                          {getSlotTimeOnly(ts.time)} {lang === 'ur' ? ' (دستیاب)' : ' (Available)'}
                                        </option>
                                      );
                                    })}
                                  </select>
                                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-5 text-blue-550">
                                    <Clock className="w-5 h-5" />
                                  </div>
                                </div>
                              </>
                            );
                          })()}

                          {/* Dynamic option view feedback */}
                          {selectedSlot && (
                            <motion.div 
                              initial={{ opacity: 0, y: 5 }} 
                              animate={{ opacity: 1, y: 0 }} 
                              className="p-4 bg-blue-50 border border-blue-100/50 rounded-2xl flex items-center justify-between"
                            >
                              <div className="space-y-0.5">
                                <span className="block text-[10px] font-bold text-blue-700 tracking-wider uppercase">{lang === 'ur' ? 'منتخب سلاٹ ٹائم:' : 'SELECTED TIME SLOT:'}</span>
                                <span className="text-sm font-extrabold text-blue-900">{getLocalizedSlotLabel(selectedSlot, lang)}</span>
                              </div>
                              <span className="bg-emerald-100 border border-emerald-250 text-emerald-850 px-3.5 py-1 rounded-full text-[10.5px] font-bold uppercase">{t.available}</span>
                            </motion.div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                {/* Area 2: Desktop Booking details request confirmation form */}
                <div className="lg:col-span-1">
                  <AnimatePresence mode="wait">
                    {selectedSlot ? (
                      <motion.div 
                        key="booking-form"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="bg-white rounded-3xl p-6 shadow-md border border-slate-100 space-y-6 sticky top-24"
                        dir={isRtl ? "rtl" : "ltr"}
                        id="booking_form_panel"
                      >
                        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                          <h4 className="font-extrabold text-slate-900 text-lg">{t.bookingDetails}</h4>
                          <button 
                            className="text-slate-400 hover:text-slate-600 text-sm font-bold"
                            onClick={() => {
                              setSelectedSlot(null);
                              setBookingNotes('');
                            }}
                          >
                            ✕
                          </button>
                        </div>

                        {/* Booking Summary details */}
                        <div className={`p-4 bg-blue-50/50 rounded-2xl border border-blue-50/40 space-y-3.5 ${isRtl ? 'text-right' : 'text-left'}`}>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4.5 h-4.5 text-blue-600" />
                            <span className="text-xs font-semibold text-slate-500">{t.bookingDateLabel}</span>
                            <span className="text-sm font-extrabold text-slate-800">{formatBilingualDate(selectedDate, lang)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="w-4.5 h-4.5 text-blue-600" />
                            <span className="text-xs font-semibold text-slate-500">{t.bookingSlotLabel}</span>
                            <span className="text-sm font-extrabold text-slate-800">
                              {getLocalizedSlotLabel(selectedSlot, lang)}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <User className="w-4.5 h-4.5 text-blue-600" />
                            <span className="text-xs font-semibold text-slate-500">{t.bookingUserLabel}</span>
                            <span className="text-sm font-extrabold text-slate-800">{user.displayName || (isRtl ? 'صارف' : 'User')}</span>
                          </div>
                        </div>

                        {/* Additional Notes info input details */}
                        <div className={`space-y-1.5 ${isRtl ? 'text-right' : 'text-left'}`}>
                          <label className="block text-xs font-extrabold text-slate-500" htmlFor="booking_notes">{t.additionalNotesLabel}</label>
                          <textarea 
                            id="booking_notes"
                            rows={3}
                            placeholder={t.additionalNotesPlaceholder}
                            value={bookingNotes}
                            onChange={(e) => setBookingNotes(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 p-3 rounded-2xl text-xs sm:text-sm font-medium focus:outline-none focus:border-blue-500 focus:bg-white resize-none"
                            dir="auto"
                          />
                        </div>

                        {/* Confirm Submit Action */}
                        <button 
                          onClick={reschedulingBooking ? rescheduleSelectedBooking : bookSelectedSlot}
                          disabled={isBookingInProgress}
                          className="w-full h-12 cursor-pointer bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-2xl shadow-md shadow-blue-100 flex items-center justify-center gap-2 disabled:bg-slate-300 disabled:shadow-none transition-all"
                          id="submit_booking_confirm"
                        >
                          {isBookingInProgress ? (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin text-white" />
                              {t.bookingInProgressBtn}
                            </>
                          ) : (
                            <>
                              <Check className="w-4.5 h-4.5 text-white" />
                              {reschedulingBooking ? (t.confirmReschedule || "Confirm Reschedule") : t.confirmBookingBtn}
                            </>
                          )}
                        </button>
                      </motion.div>
                    ) : (
                      <div className="hidden lg:flex flex-col items-center justify-center h-full bg-white rounded-3xl p-8 shadow-sm border border-slate-100 text-center sticky top-24" id="empty_booking_guide">
                        <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 mb-4 border border-slate-100/50">
                          <Smartphone className="w-6 h-6" />
                        </div>
                        <h4 className="font-extrabold text-slate-700 mb-1">{t.noTimeSelectedTitle}</h4>
                        <p className="text-slate-400 text-xs max-w-[200px] leading-relaxed">
                          {t.noTimeSelectedDesc}
                        </p>
                      </div>
                    )}
                  </AnimatePresence>
                </div>

              </div>
              </div>
              );
            })()}

            {/* B. MY BOOKINGS HISTORY TAB CONTENT */}
            {activeTab === 'my-bookings' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100"
                id="tab_my_bookings_content"
              >
                <div className="flex items-center gap-3 border-b border-slate-100 pb-5 mb-5 justify-between">
                  <div className="flex items-center gap-2.5">
                    <BookmarkCheck className="w-5.5 h-5.5 text-blue-600" />
                    <h3 className="font-extrabold text-slate-900 p-0 m-0 text-base md:text-lg">{t.myBookingsTitle} ({myBookings.length})</h3>
                  </div>
                </div>

                {bookingsLoading ? (
                  /* Animated premium loading state skeletons */
                  <div className="space-y-4 py-4" id="bookings_list_skeletons">
                    {[1, 2].map((i) => (
                      <div key={i} className="animate-pulse p-6 rounded-3xl border border-slate-100 bg-slate-50/50 flex flex-col md:flex-row justify-between gap-5">
                        <div className="flex items-start gap-4 flex-1">
                          <div className="w-12 h-12 bg-slate-200 rounded-2xl shrink-0"></div>
                          <div className="space-y-3 flex-1">
                            <div className="h-4.5 bg-slate-200 rounded-lg w-1/3"></div>
                            <div className="h-3.5 bg-slate-100/80 rounded-md w-1/2"></div>
                            <div className="h-10 bg-slate-200/50 rounded-2xl w-3/4"></div>
                          </div>
                        </div>
                        <div className="w-32 h-10 bg-slate-200 rounded-xl shrink-0 self-end md:self-center"></div>
                      </div>
                    ))}
                  </div>
                ) : myBookings.length === 0 ? (
                  /* High quality aesthetic empty state card */
                  <div className="text-center py-16 px-4 bg-slate-50/30 rounded-3xl border-2 border-dashed border-slate-100" id="empty_bookings_view">
                    <div className="w-16 h-16 bg-blue-50/75 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-50">
                      <BookmarkCheck className="w-8 h-8 animate-bounce" />
                    </div>
                    <h4 className="font-extrabold text-slate-800 text-lg mb-1 leading-snug">{t.emptyRecordTitle}</h4>
                    <p className="text-slate-400 text-sm max-w-sm mx-auto leading-relaxed mb-6">
                      {t.emptyRecordDesc}
                    </p>
                    <button 
                      onClick={() => setActiveTab('schedule')}
                      className="inline-flex items-center gap-2 px-6 py-3 cursor-pointer bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-2xl text-center text-xs transition-all shadow-md shadow-blue-100 active:scale-98"
                    >
                      <Calendar className="w-4 h-4 text-white" />
                      {t.bookSlotNowBtn}
                    </button>
                  </div>
                ) : (
                  /* Ticket-shaped structured cards */
                  <div className="space-y-4">
                    {myBookings.map((bk) => {
                      const isActive = bk.status === 'booked';
                      return (
                        <div 
                          key={bk.id}
                          className={`p-6 rounded-3xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-5 relative overflow-hidden ${
                            isActive 
                            ? 'bg-gradient-to-br from-white to-blue-50/10 border-blue-100/70 hover:border-blue-300 shadow-sm' 
                            : 'bg-slate-50 border-slate-150 opacity-65'
                          }`}
                          id={`booking_record_${bk.id}`}
                        >
                          {/* Left solid color accent bar for booked state */}
                          <div className={`absolute top-0 bottom-0 left-0 w-1.5 ${isActive ? 'bg-blue-600' : 'bg-slate-300'}`} />

                          <div className={`flex flex-col md:flex-row items-start md:items-center gap-5 ${isRtl ? 'text-right' : 'text-left'} flex-1`}>
                            {/* status badge indicator */}
                            <div className="shrink-0">
                              {isActive ? (
                                <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center shadow-xs border border-emerald-100">
                                  <CheckCircle2 className="w-6 h-6" />
                                </div>
                              ) : (
                                <div className="w-12 h-12 bg-slate-100 text-slate-400 rounded-2xl flex items-center justify-center border border-slate-200">
                                  <XCircle className="w-6 h-6" />
                                </div>
                              )}
                            </div>

                            {/* Booking info descriptions */}
                            <div className="space-y-2 flex-1 w-full">
                              {/* Date, Time, Status Labels */}
                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 divide-y sm:divide-y-0 sm:divide-x sm:divide-slate-100 leading-snug w-full">
                                
                                {/* Slot Date */}
                                <div className="pt-2 sm:pt-0">
                                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                                    {lang === 'ur' ? 'تاریخ' : 'DATE'}
                                  </span>
                                  <span className={`text-sm sm:text-base font-extrabold ${isActive ? 'text-slate-900' : 'text-slate-500'}`}>
                                    {formatBilingualDate(bk.date, lang)}
                                  </span>
                                </div>

                                {/* Slot Time */}
                                <div className="pt-2 sm:pt-0 sm:pl-4">
                                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1_custom">
                                    {lang === 'ur' ? 'ٹائم سلاٹ (Time)' : 'TIME SLOT'}
                                  </span>
                                  <span className={`text-sm sm:text-base font-extrabold ${isActive ? 'text-blue-600 pt-0.5' : 'text-slate-500 pt-0.5'} flex items-center gap-1.5`}>
                                    <Clock className="w-4 h-4 shrink-0 text-blue-500" />
                                    {getLocalizedSlotLabel(bk.slot, lang)}
                                  </span>
                                </div>

                                {/* Status */}
                                <div className="pt-2 sm:pt-0 sm:pl-4">
                                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                                    {lang === 'ur' ? 'حیثیت' : 'STATUS'}
                                  </span>
                                  <span className={`inline-flex items-center gap-1 text-xs px-3 py-1 rounded-full font-bold pt-1 ${
                                    isActive 
                                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-200 shadow-sm' 
                                    : 'bg-slate-200 text-slate-600 border border-slate-300'
                                  }`}>
                                    {isActive ? (
                                      <>
                                        <Check className="w-3.5 h-3.5" />
                                        {t.statusBooked}
                                      </>
                                    ) : (
                                      <>
                                        <XCircle className="w-3.5 h-3.5 text-slate-500" />
                                        {t.statusCancelled}
                                      </>
                                    )}
                                  </span>
                                </div>

                              </div>

                              {/* Customer Message details */}
                              {bk.notes && (
                                <div className="mt-3 text-xs text-slate-500 max-w-xl leading-relaxed flex items-start gap-2.5 bg-slate-50/80 p-3 rounded-2xl border border-slate-100">
                                  <FileText className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                                  <div className="flex-1">
                                    <span className="block text-[9px] font-extrabold text-blue-800 uppercase tracking-widest mb-0.5">{lang === 'ur' ? 'نوٹ / پیغام' : 'NOTES / MESSAGE'}</span>
                                    <span className="font-semibold text-slate-700">"{bk.notes}"</span>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Cancellation trigger */}
                          {isActive && (
                            <div className="flex flex-col sm:flex-row justify-end items-stretch sm:items-center gap-2 mt-3 sm:mt-0 w-full sm:w-auto shrink-0 font-sans">
                              <button
                                onClick={() => {
                                  // Check 3 hour restriction (unless admin)
                                  if (!isAdminUser) {
                                    const [year, month, day] = bk.date.split('-').map(Number);
                                    const [hour, minute] = bk.slot.split(':').map(Number);
                                    const appointmentDate = new Date(year, month - 1, day, hour, minute);
                                    const appointmentTime = appointmentDate.getTime();
                                    const nowTime = new Date().getTime();
                                    const hoursDiff = (appointmentTime - nowTime) / (1000 * 60 * 60);

                                    if (hoursDiff < 3) {
                                      triggerAlert('error', t.rescheduleLimitError);
                                      return;
                                    }
                                  }
                                  setReschedulingBooking(bk);
                                  setSelectedDate(bk.date);
                                  setSelectedSlot(null);
                                  setActiveTab('schedule');
                                }}
                                className="px-4 py-2.5 sm:h-11 cursor-pointer bg-blue-50 hover:bg-blue-100 text-blue-700 font-extrabold rounded-2xl text-[11px] sm:text-xs transition-all border border-blue-100 text-center flex-1 sm:flex-none"
                              >
                                {t.rescheduleBtn}
                              </button>
                              <button
                                onClick={() => cancelBooking(bk)}
                                className="px-5 py-2.5 sm:h-11 cursor-pointer bg-red-50 hover:bg-rose-100 text-red-600 hover:text-red-700 font-extrabold rounded-2xl text-[11px] sm:text-xs transition-all border border-red-100/50 hover:border-red-200 text-center flex-1 sm:flex-none"
                                id={`cancel_btn_${bk.id}`}
                              >
                                {t.cancelAppointmentBtn}
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </motion.div>
            )}

            {/* C. ADMIN CONTROLS TAB CONTENT */}
            {activeTab === 'admin' && isAdminUser && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-8"
                id="tab_admin_content"
              >
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                  <div className="flex items-center gap-3 border-b border-slate-100 pb-5 mb-5 justify-between">
                    <div className="flex items-center gap-2.5">
                      <Lock className="w-5.5 h-5.5 text-blue-600 animate-pulse" />
                      <h3 className="font-extrabold text-slate-900 p-0 m-0 text-lg">{t.adminPanelTitle}</h3>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Form to create slot */}
                    <div className="space-y-4">
                      <h4 className="font-bold text-slate-800 text-sm border-b border-slate-100 pb-2 flex items-center gap-1.5">
                        <Clock className="w-4 h-4 text-blue-500" />
                        {t.addCustomSlotTitle}
                      </h4>
                      <form onSubmit={handleAdminCreateSlot} className="space-y-4">
                        <div>
                          <label className="block text-xs font-bold text-slate-500 mb-1.5">{t.slotDateLabel}</label>
                          <input 
                            type="date"
                            value={adminSelectedDate || selectedDate}
                            onChange={(e) => setAdminSelectedDate(e.target.value)}
                            min={upcomingDays[0].dateString}
                            className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 transition-colors"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-500 mb-1.5">{t.slotTimeLabel}</label>
                          <select 
                            value={adminSelectedTime}
                            onChange={(e) => setAdminSelectedTime(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 transition-colors"
                            required
                          >
                            <option value="08:00">08:00 AM</option>
                            <option value="08:30">08:30 AM</option>
                            <option value="09:00">09:00 AM</option>
                            <option value="09:30">09:30 AM</option>
                            <option value="10:00">10:00 AM</option>
                            <option value="10:30">10:30 AM</option>
                            <option value="11:00">11:00 AM</option>
                            <option value="11:30">11:30 AM</option>
                            <option value="12:00">12:00 PM</option>
                            <option value="12:30">12:30 PM</option>
                            <option value="13:00">01:00 PM</option>
                            <option value="13:30">01:30 PM</option>
                            <option value="14:00">02:00 PM</option>
                            <option value="14:30">02:30 PM</option>
                            <option value="15:00">03:00 PM</option>
                            <option value="15:30">03:30 PM</option>
                            <option value="16:00">04:00 PM</option>
                            <option value="16:30">04:30 PM</option>
                            <option value="17:00">05:00 PM</option>
                            <option value="17:30">05:30 PM</option>
                            <option value="18:00">06:00 PM</option>
                            <option value="18:30">06:30 PM</option>
                            <option value="19:00">07:00 PM</option>
                            <option value="19:30">07:30 PM</option>
                            <option value="20:00">08:00 PM</option>
                          </select>
                        </div>
                        <button 
                          type="submit"
                          disabled={isAdminCreatingSlot}
                          className="w-full h-11 bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-blue-100 transition-all disabled:bg-slate-300 active:scale-98"
                        >
                          {isAdminCreatingSlot ? (
                            <Loader2 className="w-4 h-4 animate-spin text-white" />
                          ) : (
                            <Clock className="w-4 h-4 text-white" />
                          )}
                          {t.addSlotBtn}
                        </button>
                      </form>
                    </div>

                    {/* Manage active custom slots for selected date */}
                    <div className="space-y-4">
                      <h4 className="font-bold text-slate-800 text-sm border-b border-slate-100 pb-2 flex items-center gap-1.5">
                        <CalendarDays className="w-4 h-4 text-blue-500" />
                        {lang === 'ur' ? `فعال کسٹم سلاٹس برائے ${formatBilingualDate(selectedDate, lang)}` : `Custom Slots for ${formatBilingualDate(selectedDate, lang)}`}
                      </h4>
                      {customSlots.length === 0 ? (
                        <p className="text-xs text-slate-400 italic py-4">{lang === 'ur' ? "اس تاریخ کے لیے کوئی کسٹم سلاٹ نہیں ہے۔" : "No custom slots for this date."}</p>
                      ) : (
                        <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                          {customSlots.map(cs => (
                            <div key={cs.id} className="p-3 bg-slate-50 rounded-xl flex items-center justify-between border border-slate-100">
                              <span className="text-xs font-bold text-slate-700">{getSlotTimeOnly(cs.slot)}</span>
                              <button 
                                onClick={() => handleAdminDeleteCustomSlot(cs.id)}
                                className="text-[10px] font-bold text-red-600 bg-red-50 hover:bg-red-100 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer"
                              >
                                {t.deleteSlotBtn}
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* 2. CALENDAR OPENING & HOLIDAY CONFIGURATION */}
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-6" id="admin_calendar_config_card">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3 font-sans">
                    <CalendarRange className="w-5.5 h-5.5 text-blue-600 animate-pulse" />
                    <h3 className="font-extrabold text-slate-900 text-base">
                      {lang === 'ur' ? 'کیلنڈر کی عمومی تعطیلات اور کھلنے کے دن' : 'Calendar General Opening & Holiday Exclusions'}
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 font-sans">
                    {/* Column 1: Weekly open weekdays selection */}
                    <div className="space-y-4">
                      <h4 className="font-bold text-slate-800 text-sm border-b border-slate-100 pb-2 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        {lang === 'ur' ? 'ہفتہ وار کھلنے والے دن (Weekly Open Days)' : 'Weekly Open weekdays'}
                      </h4>
                      <p className="text-[11px] text-slate-400 font-semibold leading-relaxed">
                        {lang === 'ur' 
                          ? 'ان دنوں کو نشان زد کریں جب صارفین کیلنڈر میں سلاٹس بک کر سکیں (سنیچر عام طور پر چھٹی ہے)' 
                          : 'Check the days when users are allowed to make bookings (Saturdays are normally holidays)'}
                      </p>
                      
                      <div className="grid grid-cols-2 gap-2.5 pt-2">
                        {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map((dayName) => {
                          const isChecked = calendarSettings.openDays.includes(dayName);
                          // Urdu translations for weekdays
                          const urDayTranslation: Record<string, string> = {
                            'Sunday': 'اتوار (Sunday)',
                            'Monday': 'پیر (Monday)',
                            'Tuesday': 'منگل (Tuesday)',
                            'Wednesday': 'بدھ (Wednesday)',
                            'Thursday': 'جمعرات (Thursday)',
                            'Friday': 'جمعہ (Friday)',
                            'Saturday': 'سنیچر (Saturday)'
                          };
                          
                          return (
                            <label 
                              key={dayName}
                              className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition-all select-none ${
                                isChecked 
                                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900 font-bold' 
                                : 'bg-slate-50 border-slate-150 text-slate-500 font-semibold hover:bg-slate-100'
                              }`}
                            >
                              <input 
                                type="checkbox"
                                checked={isChecked}
                                onChange={async () => {
                                  let newOpenDays = [...calendarSettings.openDays];
                                  if (isChecked) {
                                    newOpenDays = newOpenDays.filter(d => d !== dayName);
                                  } else {
                                    newOpenDays.push(dayName);
                                  }
                                  await handleUpdateCalendarSettings({ openDays: newOpenDays });
                                }}
                                className="accent-emerald-600 rounded"
                              />
                              <span className="text-xs">
                                {lang === 'ur' ? urDayTranslation[dayName] : dayName}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Column 2: Specific Dates configurations & overrides */}
                    <div className="space-y-4">
                      <h4 className="font-bold text-slate-800 text-sm border-b border-slate-100 pb-2 flex items-center gap-1.5">
                        <AlertCircle className="w-4 h-4 text-orange-500" />
                        {lang === 'ur' ? 'مخصوص تاریخوں کی تبدیلیاں (Overrides)' : 'Override Specific Dates'}
                      </h4>
                      <p className="text-[11px] text-slate-400 font-semibold leading-relaxed">
                        {lang === 'ur'
                          ? 'کسی مخصوص تاریخ کو بند کرنے یا خاص طور پر کھولنے (جیسے سنیچر کی خاص شمولیت) کے لیے درج کریں'
                          : 'Configure specific dates to force them closed (holiday) or force them open (special addition)'}
                      </p>

                      <form onSubmit={handleAddCustomDateSetting} className="flex flex-wrap gap-3 items-end bg-slate-50 p-4 rounded-2xl border border-slate-100">
                        <div className="flex-1 min-w-[130px]">
                          <label className="block text-[10px] font-bold text-slate-500 mb-1">{lang === 'ur' ? 'تاریخ کا انتخاب کریں' : 'Select Date'}</label>
                          <input 
                            type="date"
                            value={adminCustomConfigDate}
                            onChange={(e) => setAdminCustomConfigDate(e.target.value)}
                            min={upcomingDays[0].dateString}
                            className="w-full bg-white border border-slate-200 p-2 text-xs font-semibold focus:outline-none rounded-xl"
                            required
                          />
                        </div>
                        <div className="flex-1 min-w-[130px]">
                          <label className="block text-[10px] font-bold text-slate-500 mb-1">{lang === 'ur' ? 'تبدیلی کی قسم' : 'Action Type'}</label>
                          <select
                            value={adminCustomConfigType}
                            onChange={(e) => setAdminCustomConfigType(e.target.value as any)}
                            className="w-full bg-white border border-slate-200 p-2 text-xs font-semibold focus:outline-none rounded-xl cursor-pointer"
                            required
                          >
                            <option value="holiday">{lang === 'ur' ? 'تعطیل (Force Close)' : 'Holiday / Closed'}</option>
                            <option value="special">{lang === 'ur' ? 'خصوصی شمولیت (Force Open)' : 'Special Opening'}</option>
                          </select>
                        </div>
                        <button 
                          type="submit" 
                          disabled={isUpdatingSettings || !adminCustomConfigDate}
                          className="px-4 h-9 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-md transition-all shrink-0 cursor-pointer disabled:bg-slate-300"
                        >
                          {isUpdatingSettings ? '...' : (lang === 'ur' ? 'شامل کریں' : 'Add')}
                        </button>
                      </form>

                      {/* Overridden Lists View */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                        {/* List of Special Opened */}
                        <div className="space-y-2">
                          <span className="block text-[10px] font-extrabold text-blue-700 uppercase tracking-widest">{lang === 'ur' ? 'خاص طور پر کھلے دن' : 'FORCED OPEN (Special)'}</span>
                          {calendarSettings.specialOpenDates.length === 0 ? (
                            <p className="text-[10px] text-slate-400 italic font-semibold">{lang === 'ur' ? 'کوئی تاریخ نہیں ہے' : 'No overridden open dates'}</p>
                          ) : (
                            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                              {calendarSettings.specialOpenDates.map(dateStr => (
                                <div key={dateStr} className="p-2.5 bg-blue-50/50 rounded-xl flex items-center justify-between border border-blue-100 text-[10px]">
                                  <span className="font-extrabold text-blue-800">{formatBilingualDate(dateStr, lang)}</span>
                                  <button 
                                    type="button"
                                    onClick={() => handleRemoveCustomDateSetting(dateStr, 'special')}
                                    className="text-red-500 hover:text-red-700 font-bold hover:scale-110 transition-transform cursor-pointer"
                                  >
                                    ×
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* List of Forced Holidays */}
                        <div className="space-y-2">
                          <span className="block text-[10px] font-extrabold text-orange-700 uppercase tracking-widest">{lang === 'ur' ? 'منسوخ چھٹیاں' : 'FORCED CLOSED (Holidays)'}</span>
                          {calendarSettings.holidayDates.length === 0 ? (
                            <p className="text-[10px] text-slate-400 italic font-semibold">{lang === 'ur' ? 'کوئی تاریخ نہیں ہے' : 'No custom holidays listed'}</p>
                          ) : (
                            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                              {calendarSettings.holidayDates.map(dateStr => (
                                <div key={dateStr} className="p-2.5 bg-orange-50/50 rounded-xl flex items-center justify-between border border-orange-100 text-[10px]">
                                  <span className="font-extrabold text-orange-800">{formatBilingualDate(dateStr, lang)}</span>
                                  <button 
                                    type="button"
                                    onClick={() => handleRemoveCustomDateSetting(dateStr, 'holiday')}
                                    className="text-red-500 hover:text-red-700 font-bold hover:scale-110 transition-transform cursor-pointer"
                                  >
                                    ×
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* All Users bookings list */}
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                  <div className="border-b border-slate-100 pb-4 mb-5 flex items-center justify-between">
                    <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
                      <BookmarkCheck className="w-5 h-5 text-blue-600" />
                      {t.allBookingsTitle}
                    </h3>
                    <span className="text-xs font-bold px-3 py-1 bg-slate-100 text-slate-700 rounded-full font-mono">{allBookings.length} bookings</span>
                  </div>

                  {allBookingsLoading ? (
                    /* Elegant pulsing loader list for all admin bookings */
                    <div className="space-y-4 py-4" id="all_bookings_skeletons">
                      {[1, 2].map((i) => (
                        <div key={i} className="animate-pulse p-6 rounded-3xl border border-slate-100 bg-slate-50/50 flex flex-col md:flex-row justify-between gap-5">
                          <div className="flex items-start gap-4 flex-1">
                            <div className="w-12 h-12 bg-slate-200 rounded-2xl shrink-0"></div>
                            <div className="space-y-3 flex-1">
                              <div className="h-4.5 bg-slate-200 rounded-lg w-1/3"></div>
                              <div className="h-3.5 bg-slate-100/80 rounded-md w-1/2"></div>
                              <div className="h-10 bg-slate-200/50 rounded-2xl w-3/4"></div>
                            </div>
                          </div>
                          <div className="w-32 h-10 bg-slate-200 rounded-xl shrink-0 self-end md:self-center"></div>
                        </div>
                      ))}
                    </div>
                  ) : allBookings.length === 0 ? (
                    <div className="text-center py-12 text-slate-400 bg-slate-50/50 rounded-3xl border-2 border-dashed border-slate-100">
                      <FileText className="w-11 h-11 mx-auto mb-2 opacity-50 text-slate-300" />
                      <p className="text-sm font-semibold">{t.noBookingsYet}</p>
                    </div>
                  ) : (
                    <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
                      {allBookings.map((bk) => {
                        const isActive = bk.status === 'booked';
                        return (
                          <div 
                            key={bk.id}
                            className={`p-6 rounded-3xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-5 relative overflow-hidden ${
                              isActive 
                              ? 'bg-gradient-to-br from-white to-blue-50/5 border-slate-100 hover:border-slate-250 shadow-xs' 
                              : 'bg-slate-50 border-slate-150 opacity-60'
                            }`}
                          >
                            {/* Left accent color bar */}
                            <div className={`absolute top-0 bottom-0 left-0 w-1.5 ${isActive ? 'bg-indigo-600' : 'bg-slate-300'}`} />

                            <div className="flex flex-col md:flex-row items-start md:items-center gap-5 flex-1 w-full">
                              {/* Left status badge */}
                              <div className="shrink-0">
                                {isActive ? (
                                  <div className="w-11 h-11 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center border border-indigo-100 shadow-xs">
                                    <User className="w-5.5 h-5.5" />
                                  </div>
                                ) : (
                                  <div className="w-11 h-11 bg-slate-100 text-slate-400 rounded-2xl flex items-center justify-center border border-slate-200">
                                    <XCircle className="w-5.5 h-5.5" />
                                  </div>
                                )}
                              </div>

                              <div className="space-y-2 flex-1 w-full text-left">
                                {/* Grid container */}
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 divide-y sm:divide-y-0 sm:divide-x sm:divide-slate-100 leading-snug w-full border-b border-slate-100/50 pb-2">
                                  
                                  {/* Slot Date */}
                                  <div>
                                    <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                                      {lang === 'ur' ? 'تاریخ' : 'DATE'}
                                    </span>
                                    <span className={`text-xs md:text-sm font-extrabold ${isActive ? 'text-slate-900' : 'text-slate-500'}`}>
                                      {formatBilingualDate(bk.date, lang)}
                                    </span>
                                  </div>

                                  {/* Slot Time */}
                                  <div className="pt-2 sm:pt-0 sm:pl-4">
                                    <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                                      {lang === 'ur' ? 'ٹائم سلاٹ' : 'TIME SLOT'}
                                    </span>
                                    <span className={`text-xs md:text-sm font-extrabold ${isActive ? 'text-indigo-600' : 'text-slate-500'} flex items-center gap-1`}>
                                      <Clock className="w-3.5 h-3.5 shrink-0 text-indigo-500" />
                                      {getLocalizedSlotLabel(bk.slot, lang)}
                                    </span>
                                  </div>

                                  {/* Status */}
                                  <div className="pt-2 sm:pt-0 sm:pl-4">
                                    <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                                      {lang === 'ur' ? 'حیثیت' : 'STATUS'}
                                    </span>
                                    <span className={`inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full font-bold ${
                                      isActive 
                                      ? 'bg-blue-100 text-blue-800' 
                                      : 'bg-slate-200 text-slate-600'
                                    }`}>
                                      {isActive ? t.statusBooked : t.statusCancelled}
                                    </span>
                                  </div>

                                </div>

                                <div className="text-xs space-y-1 pt-1">
                                  <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-slate-700 font-medium">
                                    <span className="font-extrabold text-slate-950">{bk.userName}</span>
                                    <span className="text-slate-400 text-[11px] font-mono">({bk.userEmail})</span>
                                  </div>
                                  
                                  {bk.notes && (
                                    <div className="text-[11px] text-slate-500 max-w-xl italic bg-slate-50 p-2.5 rounded-xl border border-slate-150 leading-relaxed mt-1">
                                      "{bk.notes}"
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>

                            {isActive && (
                              <div className="flex flex-col sm:flex-row justify-end items-stretch sm:items-center gap-2 mt-2 sm:mt-0 w-full sm:w-auto shrink-0 font-sans">
                                <button
                                  onClick={() => {
                                    setReschedulingBooking(bk);
                                    setSelectedDate(bk.date);
                                    setSelectedSlot(null);
                                    setActiveTab('schedule');
                                    triggerAlert('success', lang === 'ur' ? 'ایڈمن موڈ: نئی تاریخ اور دستیاب کسٹم ضرورت کے مطابق تبدیل کریں۔' : 'Admin Reschedule Mode: Pick target reschedule date & slot.');
                                  }}
                                  className="px-3.5 py-2 sm:h-9.5 cursor-pointer bg-blue-50 hover:bg-blue-100 text-blue-700 font-extrabold rounded-xl text-[11px] sm:text-xs transition-all border border-blue-100 text-center flex-1 sm:flex-none"
                                >
                                  {lang === 'ur' ? 'تبدیل کریں' : 'Reschedule'}
                                </button>
                                <button
                                  onClick={() => adminCancelBooking(bk)}
                                  className="px-4.5 py-2 sm:h-9.5 cursor-pointer bg-red-50 hover:bg-red-100 text-red-650 hover:text-red-700 font-extrabold rounded-xl text-[11px] sm:text-xs transition-all border border-red-100/70 text-center flex-1 sm:flex-none"
                                >
                                  {t.cancelAppointmentBtn}
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </motion.div>
            )}

          </div>

        </main>
      )}

      {/* Booking Form slide-over dialog for mobile screens */}
      <AnimatePresence>
        {selectedSlot && (
          <div className="lg:hidden fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-xs" id="mobile_dialog">
            
            {/* Backdrop cancel */}
            <div className="absolute inset-0" onClick={() => setSelectedSlot(null)} />

            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="relative w-full max-w-md bg-white rounded-t-3xl p-6 pb-8 space-y-6 shadow-2xl z-10"
              dir={isRtl ? "rtl" : "ltr"}
            >
              {/* handle grabber bar */}
              <div className="w-12 h-1 bg-slate-200 rounded-full mx-auto mb-1" />

              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="font-extrabold text-slate-900 text-base">{t.mobileBookTitle}</h4>
                <button 
                  className="text-slate-400 hover:text-slate-600 font-bold"
                  onClick={() => {
                    setSelectedSlot(null);
                    setBookingNotes('');
                  }}
                >
                  ✕
                </button>
              </div>

              {/* slot details preview card */}
              <div className={`p-4 bg-blue-50/50 rounded-2xl border border-blue-50/30 space-y-3 ${isRtl ? 'text-right' : 'text-left'}`}>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4.5 h-4.5 text-blue-600" />
                  <span className="text-xs font-semibold text-slate-500">{t.bookingDateLabel}</span>
                  <span className="text-sm font-extrabold text-slate-800">{formatBilingualDate(selectedDate, lang)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4.5 h-4.5 text-blue-600" />
                  <span className="text-xs font-semibold text-slate-500">{t.bookingSlotLabel}</span>
                  <span className="text-sm font-extrabold text-slate-800 font-sans">
                    {getLocalizedSlotLabel(selectedSlot, lang)}
                  </span>
                </div>
              </div>

              <div className={`space-y-1.5 ${isRtl ? 'text-right' : 'text-left'}`}>
                <label className="block text-xs font-bold text-slate-600" htmlFor="mobile_booking_notes">{t.additionalNotesLabel}</label>
                <textarea 
                  id="mobile_booking_notes"
                  rows={2}
                  placeholder={t.mobileNotesPlaceholder}
                  value={bookingNotes}
                  onChange={(e) => setBookingNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 p-3 rounded-2xl text-xs sm:text-sm font-medium focus:outline-none focus:border-blue-500 focus:bg-white resize-none"
                  dir="auto"
                />
              </div>

              <button 
                onClick={reschedulingBooking ? rescheduleSelectedBooking : bookSelectedSlot}
                disabled={isBookingInProgress}
                className="w-full h-12 cursor-pointer bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl shadow-md shadow-blue-100 flex items-center justify-center gap-2 disabled:bg-slate-300 disabled:shadow-none transition-all"
                id="mobile_submit_confirm"
              >
                {isBookingInProgress ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    {t.bookingInProgressBtn}
                  </>
                ) : (
                  <>
                    <Check className="w-4.5 h-4.5 text-white" />
                    {reschedulingBooking ? (t.confirmReschedule || "Confirm Reschedule") : t.confirmBookingBtn}
                  </>
                )}
              </button>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer copyright */}
      <footer className="py-8 bg-white border-t border-slate-100 text-center text-xs text-slate-400 mt-16">
        <div className="max-w-7xl mx-auto px-4">
          <p>{t.footerText.replace('{year}', String(new Date().getFullYear()))}</p>
          <p className="mt-1 font-mono text-[10px] text-slate-300">{t.footerSubtext}</p>
        </div>
      </footer>

    </div>
  );
}
