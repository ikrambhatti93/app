export interface Booking {
  id: string; // combination of date_slot or randomized
  date: string; // YYYY-MM-DD
  slot: string; // HH:MM
  userId: string;
  userName: string;
  userEmail: string;
  status: 'booked' | 'cancelled';
  notes?: string;
  createdAt: any; // Firestore Timestamp
}

export interface BookedSlot {
  id: string; // YYYY-MM-DD_HH_MM
  date: string;
  slot: string;
  isBooked: boolean;
  userId: string;
}

export interface TimeSlotConfig {
  time: string;
  label: string;
}

export interface CalendarSettingsType {
  openDays: string[];
  specialOpenDates: string[];
  holidayDates: string[];
}

