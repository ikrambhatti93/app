export const URDU_WEEKDAYS: Record<string, string> = {
  "Sunday": "اتوار",
  "Monday": "پیر",
  "Tuesday": "منگل",
  "Wednesday": "بدھ",
  "Thursday": "جمعرات",
  "Friday": "جمعہ",
  "Saturday": "ہفتہ"
};

export const URDU_MONTHS: Record<string, string> = {
  "01": "جنوری",
  "02": "فروری",
  "03": "مارچ",
  "04": "اپریل",
  "05": "مئی",
  "06": "جون",
  "07": "جولائی",
  "08": "اگست",
  "09": "ستمبر",
  "10": "اکتوبر",
  "11": "نومبر",
  "12": "دسمبر"
};

export interface DayItem {
  dateString: string; // YYYY-MM-DD
  dayNumber: string; // "16"
  monthUrdu: string; // "جون"
  weekdayUrdu: string; // "منگل"
  weekdayEnglish: string; // "Tuesday"
  monthEnglish: string; // "June"
  weekdayEnglishShort: string; // "Tue"
  monthEnglishShort: string; // "Jun"
}

// Generates upcoming schedule days from today
export function getUpcomingDays(count: number = 14): DayItem[] {
  const days: DayItem[] = [];
  const today = new Date();
  
  for (let i = 0; i < count; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const dateNum = String(d.getDate()).padStart(2, '0');
    const dateString = `${year}-${month}-${dateNum}`;
    
    const weekdayEng = d.toLocaleDateString('en-US', { weekday: 'long' });
    const weekdayEngShort = d.toLocaleDateString('en-US', { weekday: 'short' });
    const monthEng = d.toLocaleDateString('en-US', { month: 'long' });
    const monthEngShort = d.toLocaleDateString('en-US', { month: 'short' });
    const monthNum = String(d.getMonth() + 1).padStart(2, '0');
    
    days.push({
      dateString,
      dayNumber: String(d.getDate()),
      monthUrdu: URDU_MONTHS[monthNum] || "جون",
      weekdayUrdu: URDU_WEEKDAYS[weekdayEng] || "منگل",
      weekdayEnglish: weekdayEng,
      monthEnglish: monthEng,
      weekdayEnglishShort: weekdayEngShort,
      monthEnglishShort: monthEngShort
    });
  }
  
  return days;
}

// Converts a YYYY-MM-DD date string to localized format, e.g. "16 جون (منگل)" or "16 June (Tuesday)"
export function formatBilingualDate(dateStr: string, lang: 'ur' | 'en'): string {
  if (!dateStr) return '';
  try {
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    const dateObj = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    const day = String(Number(parts[2]));
    const month = parts[1];
    const weekdayEng = dateObj.toLocaleDateString('en-US', { weekday: 'long' });
    
    if (lang === 'ur') {
      const monthUrdu = URDU_MONTHS[month] || '';
      const weekdayUrdu = URDU_WEEKDAYS[weekdayEng] || '';
      return `${day} ${monthUrdu} (${weekdayUrdu})`;
    } else {
      const monthEng = dateObj.toLocaleDateString('en-US', { month: 'long' });
      return `${day} ${monthEng} (${weekdayEng})`;
    }
  } catch (error) {
    return dateStr;
  }
}

// Converts a YYYY-MM-DD date string to localized format, e.g. "16 جون، منگل"
export function formatUrduDate(dateStr: string): string {
  return formatBilingualDate(dateStr, 'ur');
}
